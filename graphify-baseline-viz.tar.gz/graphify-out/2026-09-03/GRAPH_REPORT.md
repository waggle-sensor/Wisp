# Graph Report - $HOME/.hermes/profiles/sage  (2026-09-03)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 524 nodes · 383 edges · 207 communities (52 shown, 155 thin omitted)
- Extraction: 86% EXTRACTED · 14% INFERRED · 0% AMBIGUOUS · INFERRED: 52 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `233d5efc`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- vss-deploy-profile
- Build BSP Source Skill
- jetson-init-image
- tao-run-automl
- Performance Tuning Guide
- Physical AI Infrastructure Setup And Resilient Scaling
- tao-run-automl
- sage-waggle skill
- TAO Run Platform
- NVIDIA RAG Blueprint
- Clinical ASR Eval
- holoscan-setup
- jetson-diagnostic
- TAO Inference Microservice
- Deep Agent Orchestration Workflow
- local-cache-design.md
- Linear Programming
- SageMaker Deployment Planner Skill
- Holoscan Setup Skill
- nemo-automodel-model-onboarding Skill
- nv-generate-mr-brain-finetune
- TAO Train Single Step
- Calibrate Sample Dataset Skill
- TileGym cuTile Python Skill
- NVIDIA TAO Skill Bank
- Clinical ASR Build Skill
- Dynamo Recipe Runner
- Gradio LoRA Space Builder
- jetson-speculative-decoding
- nemo-data-designer-plugin Skill
- Activation Recompute Skill
- Physical AI Video Data Augmentation Workflow Orchestrator
- Skill Card Generator
- AIQ Research Skill
- Data Designer Skill
- DeepStream Profiling Skill
- Dynamo Troubleshoot Skill
- Earth2Studio Create Prognostic Skill
- Earth2Studio Deterministic Forecast Skill
- hsb-setup
- Trackio Experiment Tracking
- jetson-llm-benchmark
- nemo-automodel-launcher-config Skill
- nemo-automodel-recipe-development Skill
- nemo-evaluator-plugin Skill
- nemo-mbridge-mlm-bridge-training Skill
- Auto Research
- NV-Reason-CXR
- TAO Run AutoML
- TAO Route Visual ChangeNet Samples
- OSMO Logs Reader Agent
- PhysicsNeMo GitHub Repository
- aiq-deploy skill
- cuOpt Developer Skill
- cuOpt Developer Skill
- Multi-Objective Exploration Skill
- cuPyNumeric HDF5 I/O
- cuPyNumeric Install
- DeepStream Dev Skill
- Hugging Face Paper Publisher
- jetson-inference-mem-tune
- nemo-automodel-distributed-training Benchmark
- nemo-mbridge-multi-node-slurm Benchmark
- nemo-mbridge-perf-activation-recompute Benchmark
- nemo-mbridge-perf-cpu-offloading Benchmark
- nemo-mbridge-perf-cuda-graphs Benchmark
- nv-generate-ct-rflow
- nv-generate-mr
- NV-Segment-CT
- NV-Segment-CT Finetune
- NV-Segment-CTMR
- CAD to SimReady
- TAO Analyze ChangeNet RCA Skill
- TAO CLIP Fine-tuning
- TAO Train Grounding DINO
- TAO Train Mask Auto-Encoder
- TAO Validate Dataset Format
- CUDA Toolkit 13.0
- Camp 2026 Knowledge Uptake
- NVIDIA Driver 580
- accelerated-computing-cudf skill
- Accelerated Computing cuDF Skill
- AMC Sample Calibration Skill
- AMC Video Calibration Skill
- AMC Setup Calibration Stack Skill
- CUDA-Q Guide Skill
- CUDA-Q Onboarding Guide Skill
- cuFolio Skill
- cuFOLIO Skill
- cuOpt Multi-Objective Exploration Skill
- cuOpt Routing Python API
- DALI Dynamic Mode
- DALI Imperative Dynamic Mode Skill
- Data Designer
- DeepStream Dev
- DeepStream Generate Pipeline Skill
- DeepStream Import Vision Model Skill
- DeepStream Profile Pipeline Skill
- DeepStream SOP Inference Microservice Skill
- DICOM Metadata Extract
- DICOM Metadata Extract Skill
- DICOM Series Preflight
- DICOM Series Preflight Skill
- DICOM Series to Volume
- DICOM Series to Volume Skill
- Dynamo Interconnect Check Skill
- Earth2Studio Create DataSource
- Earth2Studio Create DataSource Skill
- Earth2Studio Create Diagnostic
- Earth2Studio Create Prognostic
- Earth2Studio Data Fetch
- Earth2Studio Data Fetch Skill
- Earth2Studio Discover Skill
- Earth2Studio Install Skill
- Graphify Skill
- Hugging Face Hub CLI Skill
- Hugging Face MCP Server Skill
- HF-Mem Memory Estimation Skill
- Holoscan Install Conda Skill
- HSB App Skill
- hsb-flash
- HSB Flash Skill
- HSB Setup Skill
- HSB Test Skill
- HuggingFace Best Model Finder
- Hugging Face Dataset Viewer
- Hugging Face Local Models
- Hugging Face API Tool Builder
- HuggingFace Vision Trainer Skill
- Hugging Face ZeroGPU Skill
- Jetson Diagnostic Skill
- jetson-memory-audit
- jetson-print-bsp-info
- jetson-print-device-info
- Jetson Promote Image Skill
- Jetson Speculative Decoding Skill
- Launch NeMo RL Skill
- launch-nemo-rl
- MCore Create Issue Skill
- mcore-create-issue
- MCore Linting and Formatting Skill
- mcore-linting-and-formatting
- MCore Run on Slurm Skill
- mcore-run-on-slurm
- MCore Split PR Skill
- mcore-split-pr
- MCore Testing Skill
- mcore-testing
- mcore-testing Skill Card
- nemo-data-designer-plugin Skill Card
- Multi-Node Slurm Skill
- CPU Offloading Skill
- Hierarchical Context Parallel Skill
- MoE Communication Overlap Skill
- MoE Dispatcher Selection Skill
- MoE Hardware Configuration Skill
- MoE Training Optimization Workflow
- MoE VLM Training
- Recipe Recommender
- Resiliency
- NeMo Retriever
- nemo-rl-docs
- nemoclaw-user-guide
- nemotron-customize
- nemotron-policy-generator
- nemotron-retrieval-recipes
- nemotron-speech
- Omniverse USD Performance Tuning
- cosmos_worker.sh
- generate_configs.py
- osmo_barrier.py
- pl_augmented_worker.sh
- pl_original_worker.sh
- render_side_by_side.sh
- stage_run_artifacts.sh
- PhysicsNeMo Discoverability
- TAO Analyze Gaps VLM BCQ Skill
- TAO List Capabilities
- TAO Port HuggingFace Model
- TAO Train Image Classification
- TAO Train Mask2Former
- TAO Train Metric Learning Recognition
- TAO Train NVDINOv2
- TAO Train NVPanoptix3D
- TAO Train OCDNet
- TAO Train OCRNet
- TAO Train OneFormer
- TAO Train Optical Inspection
- TAO Train PointPillars
- TAO Train Pose Classification
- TAO Train ReID
- TAO Train RT-DETR
- RT-DETR
- TileGym Adding CuTile Kernel
- TileGym Converting cuTile to Julia
- TileGym Converting cuTile to Triton
- TileGym cuTile Autotuning Skill
- CuTile Autotuning Skill
- Iterative cuTile Kernel Performance Optimization
- Integrate cuTile kernels into Transformers
- train-sentence-transformers
- transformers-js
- trl-training
- VSS Deploy Profile Skill

## God Nodes (most connected - your core abstractions)
1. `tao-run-automl` - 16 edges
2. `vss-deploy-profile` - 14 edges
3. `Physical AI Infrastructure Setup And Resilient Scaling` - 12 edges
4. `vss-summarize-video` - 12 edges
5. `Performance Tuning Guide` - 11 edges
6. `tao-run-automl` - 9 edges
7. `vss-query-analytics` - 9 edges
8. `holoscan-setup` - 6 edges
9. `Build BSP Source Skill` - 6 edges
10. `jetson-promote-image` - 6 edges

## Surprising Connections (you probably didn't know these)
- `MoE Long-Context Training` --references--> `Performance Tuning Guide`  [EXTRACTED]
  skills/nemo-mbridge-perf-moe-long-context/SKILL.md → docs/performance-guide.md
- `Sequence Packing` --references--> `Performance Tuning Guide`  [EXTRACTED]
  skills/nemo-mbridge-perf-sequence-packing/SKILL.md → docs/performance-guide.md
- `nemo-mbridge-perf-expert-parallel-overlap` --references--> `Performance Tuning Guide`  [EXTRACTED]
  skills/nemo-mbridge-perf-expert-parallel-overlap/skill-card.md → docs/performance-guide.md
- `nemo-mbridge-perf-hierarchical-context-parallel` --references--> `Performance Tuning Guide`  [EXTRACTED]
  skills/nemo-mbridge-perf-hierarchical-context-parallel/skill-card.md → docs/performance-guide.md
- `nemo-mbridge-perf-megatron-fsdp` --references--> `Performance Tuning Guide`  [EXTRACTED]
  skills/nemo-mbridge-perf-megatron-fsdp/skill-card.md → docs/performance-guide.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **NVIDIA cuOpt Skill Suite** — skills_cuopt_developer, skills_cuopt_install, skills_cuopt_multi_objective_exploration, skills_cuopt_numerical_optimization_api, skills_cuopt_numerical_optimization_formulation, skills_cuopt_routing_api_python, skills_cuopt_server_api_python [EXTRACTED 1.00]
- **cuPyNumeric Skill Suite** — skills_cupynumeric_hdf5, skills_cupynumeric_install, skills_cupynumeric_migration_readiness, skills_cupynumeric_parallel_data_load [EXTRACTED 1.00]
- **AutoMagicCalib (AMC) Suite** — skills_amc_run_sample_calibration, skills_amc_run_video_calibration, skills_amc_setup_calibration_stack [EXTRACTED 1.00]
- **Clinical ASR Flywheel** — skills_digital_health_clinical_asr_setup_skill_card, skills_digital_health_clinical_asr_build_skill_card, skills_digital_health_clinical_asr_eval_skill_card, skills_digital_health_clinical_asr_finetune_skill_card [EXTRACTED 1.00]
- **DeepStream SDK Skills** — skills_deepstream_dev_skill_card, skills_deepstream_generate_pipeline_skill_card, skills_deepstream_import_vision_model_skill_card, skills_deepstream_profile_pipeline_skill_card, skills_deepstream_sop_skill_card [INFERRED 0.90]
- **Earth2Studio Skills** — skills_earth2studio_create_datasource_skill_card, skills_earth2studio_create_diagnostic_skill_card, skills_earth2studio_create_prognostic_skill_card, skills_earth2studio_data_fetch_skill_card, skills_earth2studio_deterministic_forecast_skill_card, skills_earth2studio_discover_skill_card, skills_earth2studio_install_skill_card [INFERRED 0.90]
- **Holoscan SDK Installation Flow** — skills_holoscan_setup_skill, skills_holoscan_install_conda_skill, skills_holoscan_install_container_skill, skills_holoscan_install_debian_skill, skills_holoscan_install_wheel_skill, skills_holoscan_install_source_skill [EXTRACTED 1.00]
- **Holoscan Sensor Bridge Lifecycle** — skills_hsb_setup_skill, skills_hsb_flash_skill, skills_hsb_app_skill, skills_hsb_test_skill [INFERRED 0.90]
- **Jetson BSP Customization Suite** — skills_jetson_derive_carrier_skill, skills_jetson_customize_uphy_skill, skills_jetson_customize_pcie_skill, skills_jetson_customize_usb_skill, skills_jetson_customize_mgbe_skill, skills_jetson_customize_pinmux_skill, skills_jetson_customize_clocks_skill, skills_jetson_customize_nvpmodel_skill, skills_jetson_customize_fan_skill [INFERRED 0.90]
- **Jetson BSP Customization Workflow** — skills_jetson_init_target, skills_jetson_init_source, skills_jetson_init_image, skills_jetson_promote_image, skills_jetson_flash_image, skills_jetson_validate_image [INFERRED 0.90]
- **Jetson LLM Deployment and Tuning** — skills_jetson_package, skills_jetson_llm_serve, skills_jetson_inference_mem_tune, skills_jetson_llm_benchmark, skills_jetson_speculative_decoding [INFERRED 0.85]
- **Megatron-Core Developer Workflow** — skills_mcore_linting_and_formatting, skills_mcore_testing, skills_mcore_run_on_slurm, skills_mcore_split_pr, skills_mcore_create_issue [INFERRED 0.90]
- **NeMo AutoModel Onboarding Documentation** — skills_nemo_automodel_model_onboarding_skill, skills_nemo_automodel_model_onboarding_llm_patterns, skills_nemo_automodel_model_onboarding_vlm_patterns, skills_nemo_automodel_model_onboarding_capabilities_and_precision [EXTRACTED 1.00]
- **NeMo Data Designer Workflow** — skills_nemo_data_designer_plugin_skill, skills_nemo_data_designer_plugin_workflows_interactive, skills_nemo_data_designer_plugin_workflows_autopilot [EXTRACTED 1.00]
- **MoE Performance Tuning Suite** — skills_nemo_mbridge_perf_moe_comm_overlap, skills_nemo_mbridge_perf_moe_dispatcher_selection, skills_nemo_mbridge_perf_moe_hardware_configs, skills_nemo_mbridge_perf_moe_long_context, skills_nemo_mbridge_perf_moe_optimization_workflow, skills_nemo_mbridge_perf_moe_vlm_training [INFERRED 0.90]
- **Physical AI Infrastructure Stack** — physical_ai_infra_azure_access, physical_ai_infra_osmo_azure, physical_ai_infra_osmo_k8s, physical_ai_infra_workflow_expert [EXTRACTED 1.00]
- **Medical Imaging Generation Skills** — skills_nv_generate_ct_rflow, skills_nv_generate_mr, skills_nv_generate_mr_brain, skills_nv_segment_ct, skills_nv_segment_ctmr [INFERRED 0.90]
- **NVIDIA RAG Blueprint Tooling** — skills_rag_blueprint, skills_rag_eval, skills_rag_perf [INFERRED 0.90]
- **TAO Visual ChangeNet Analysis Suite** — skills_tao_analyze_changenet_rca, skills_tao_analyze_gaps_visual_changenet [INFERRED 0.85]
- **TAO Execution Platforms** — skills_tao_run_on_brev, skills_tao_run_on_slurm, skills_tao_run_on_local_docker, skills_tao_run_on_kubernetes [EXTRACTED 1.00]
- **TAO Data Generation Pipeline** — skills_tao_generate_image_grounding, skills_tao_generate_referring_expressions, skills_tao_generate_video_reasoning_annotations [INFERRED 0.80]
- **TAO Model Training Skills** — skills_tao_train_action_recognition, skills_tao_train_bevfusion, skills_tao_train_centerpose, skills_tao_train_deformable_detr, skills_tao_train_depth_anything_v2, skills_tao_train_dino, skills_tao_train_fast_foundation_stereo [INFERRED 0.90]
- **NVIDIA TAO Training Skills** — skills_tao_train_fast_foundation_stereo, skills_tao_train_foundation_stereo, skills_tao_train_grounding_dino, skills_tao_train_image_classification, skills_tao_train_mask_auto_encoder, skills_tao_train_mask_auto_label, skills_tao_train_mask_grounding_dino, skills_tao_train_mask2former, skills_tao_train_metric_learning_recognition, skills_tao_train_nvdinov2, skills_tao_train_nvpanoptix3d, skills_tao_train_ocdnet, skills_tao_train_ocrnet, skills_tao_train_oneformer, skills_tao_train_optical_inspection, skills_tao_train_pointpillars, skills_tao_train_pose_classification, skills_tao_train_reid, skills_tao_train_rtdetr, skills_tao_train_segformer, skills_tao_train_single_step, skills_tao_train_sparse4d, skills_tao_train_visual_changenet [EXTRACTED 1.00]
- **TileGym cuTile Development Suite** — skills_tilegym_adding_cutile_kernel, skills_tilegym_cutile_python, skills_tilegym_cutile_autotuning, skills_tilegym_improve_cutile_kernel_perf [INFERRED 0.95]
- **VSS Deployment and Management Suite** — skills_vss_deploy_profile, skills_vss_deploy_dense_captioning, skills_vss_deploy_detection_tracking_2d, skills_vss_deploy_detection_tracking_3d, skills_vss_deploy_video_embedding [INFERRED 0.95]
- **VSS Analytics and Reporting Suite** — skills_vss_ask_video, skills_vss_generate_video_report, skills_vss_query_analytics, skills_vss_manage_alerts [INFERRED 0.90]
- **VSS Skill Suite** — skills_vss_query_analytics, skills_vss_search_archive, skills_vss_setup_behavior_analytics, skills_vss_setup_video_analytics_api, skills_vss_summarize_video [INFERRED 0.90]
- **VSS Evaluation Agents** — claude_code, codex [EXTRACTED 1.00]
- **Sage Platform Redesign** — docs_infra_problems, docs_local_cache, docs_pywaggle2 [EXTRACTED 1.00]
- **AI-Q Blueprint Ecosystem** — skills_aiq_deploy, skills_aiq_research [EXTRACTED 1.00]
- **AutoMagicCalib Calibration Workflow** — skills_amc_setup_calibration_stack_skill, skills_amc_run_sample_calibration_skill, skills_amc_run_video_calibration_skill [EXTRACTED 1.00]
- **cuOpt Development and Usage** — skills_cuopt_developer_skill, skills_cuopt_install_skill, skills_cuopt_multi_objective_exploration_skill, skills_cuopt_numerical_optimization_api_skill [INFERRED 0.90]
- **cuOpt Numerical Optimization Suite** — skills_cuopt_numerical_optimization_api, skills_cuopt_numerical_optimization_formulation, skills_cuopt_server_api_python [EXTRACTED 1.00]
- **cuPyNumeric Ecosystem** — skills_cupynumeric_hdf5, skills_cupynumeric_install, skills_cupynumeric_migration_readiness, skills_cupynumeric_parallel_data_load [EXTRACTED 1.00]
- **DICOM Processing Pipeline** — skills_dicom_metadata_extract, skills_dicom_series_preflight, skills_dicom_series_to_volume [INFERRED 0.90]
- **Dynamo Deployment Workflow** — skills_dynamo_recipe_runner, skills_dynamo_router_starter, skills_dynamo_interconnect_check, skills_dynamo_troubleshoot [INFERRED 0.90]
- **Earth2Studio Model Creation** — skills_earth2studio_create_datasource, skills_earth2studio_create_diagnostic, skills_earth2studio_create_prognostic [INFERRED 0.90]
- **SageMaker Deployment Workflow** — skills_hf_cloud_sagemaker_deployment_planner_skill, skills_hf_cloud_aws_context_discovery_skill, skills_hf_cloud_python_env_setup_skill, skills_hf_cloud_sagemaker_iam_preflight_skill, skills_hf_cloud_serving_image_selection_skill, skills_hf_cloud_sagemaker_production_defaults_skill [EXTRACTED 1.00]
- **Holoscan SDK Installation Suite** — skills_holoscan_setup, skills_holoscan_install_container, skills_holoscan_install_debian, skills_holoscan_install_wheel, skills_holoscan_install_source [EXTRACTED 1.00]
- **Holoscan Sensor Bridge Management** — skills_hsb_setup, skills_hsb_app, skills_hsb_flash, skills_hsb_test [INFERRED 0.90]
- **HF Training & Monitoring Flow** — skills_huggingface_llm_trainer, skills_huggingface_vision_trainer, skills_huggingface_trackio [EXTRACTED 1.00]
- **HF Space Creation & UI Flow** — skills_huggingface_spaces, skills_huggingface_gradio, skills_huggingface_lora_space_builder [EXTRACTED 1.00]
- **Jetson BSP Customization Workflow** — skills_jetson_init_source_skill, skills_jetson_derive_carrier_skill, skills_jetson_build_source_skill, skills_jetson_promote_image_skill [EXTRACTED 1.00]
- **Jetson Hardware Customization Skills** — skills_jetson_customize_camera_skill, skills_jetson_customize_mgbe_skill, skills_jetson_customize_pcie_skill, skills_jetson_customize_pinmux_skill [INFERRED 0.90]
- **Jetson Power and Thermal Tuning** — skills_jetson_customize_clocks_skill, skills_jetson_customize_fan_skill, skills_jetson_customize_nvpmodel_skill [INFERRED 0.90]
- **BSP Setup Flow** — skills_jetson_download_bsp, skills_jetson_init_image, skills_jetson_init_source, skills_jetson_link_docs [INFERRED 0.90]
- **BSP I/O Customization** — skills_jetson_customize_pinmux, skills_jetson_customize_uphy, skills_jetson_customize_usb [INFERRED 0.90]
- **Memory Optimization Flow** — skills_jetson_diagnostic, skills_jetson_headless_mode, skills_jetson_inference_mem_tune [INFERRED 0.80]
- **LLM Deployment and Benchmarking** — skills_jetson_llm_serve, skills_jetson_llm_benchmark, skills_jetson_package [INFERRED 0.90]
- **Jetson Deploy Pipeline** — skills_jetson_promote_image_skill, skills_jetson_flash_image_skill, skills_jetson_validate_image_skill [EXTRACTED 1.00]
- **Jetson Setup Flow** — skills_jetson_quick_start_skill, skills_jetson_set_target_skill, skills_jetson_init_target_skill, skills_jetson_download_bsp_skill, skills_jetson_init_image_skill, skills_jetson_init_source_skill [EXTRACTED 1.00]
- **GPU Memory Reduction Strategies** — skills_nemo_mbridge_perf_memory_tuning_skill, skills_nemo_mbridge_perf_activation_recompute_skill, skills_nemo_mbridge_perf_cpu_offloading_skill, skills_nemo_mbridge_perf_megatron_fsdp_skill [INFERRED 0.90]
- **MoE Performance Optimization** — skills_nemo_mbridge_perf_expert_parallel_overlap_skill, skills_nemo_mbridge_perf_moe_comm_overlap_skill, skills_nemo_mbridge_perf_moe_dispatcher_selection_skill, skills_nemo_mbridge_perf_moe_hardware_configs_skill [INFERRED 0.90]
- **NeMo-RL Research Workflow** — skills_nemo_rl_auto_research, skills_nemo_rl_session_memory, skills_nemo_rl_brev_etiquette [EXTRACTED 1.00]
- **NV-Generate-CTMR Synthesis Suite** — skills_nv_generate_ct_rflow, skills_nv_generate_mr, skills_nv_generate_mr_brain, skills_nv_generate_mr_brain_finetune, skills_nv_generate_vae_finetune [INFERRED 0.90]
- **MedTech Segmentation Suite** — skills_nv_segment_ct, skills_nv_segment_ct_finetune, skills_nv_segment_ctmr [INFERRED 0.90]
- **Omniverse USD Workflow** — skills_omniverse_cad_to_simready, skills_omniverse_realtime_viewer, skills_omniverse_usd_performance_tuning [INFERRED 0.90]
- **Physical AI Infrastructure Stack** — infra_cluster_azure, infra_cluster_microk8s, infra_osmo_cli, infra_nim_operator, infra_nvcf, infra_azure_foundry [EXTRACTED 1.00]
- **Synthetic Data Generation Workloads** — skills_physical_ai_defect_image_generation, skills_physical_ai_people_attribute_search, skills_physical_ai_video_data_augmentation [INFERRED 0.90]
- **NVIDIA RAG Blueprint Tooling** — skills_rag_eval_skill, skills_rag_perf_skill [INFERRED 0.90]
- **TAO Gap Analysis Tools** — skills_tao_analyze_gaps_visual_changenet, skills_tao_analyze_gaps_vlm_bcq [INFERRED 0.90]
- **Cosmos Model Family** — skills_tao_finetune_cosmos_embed, skills_tao_finetune_cosmos_reason [EXTRACTED 1.00]
- **VCN AOI SDA Pipeline** — skills_tao_route_visual_changenet_samples, skills_tao_mine_aoi_images [EXTRACTED 1.00]
- **VLM-based Annotation Skills** — skills_tao_generate_image_grounding, skills_tao_generate_referring_expressions, skills_tao_generate_video_reasoning_annotations [INFERRED 0.90]
- **AOI Training Pipeline Flow** — skills_tao_run_automl_skill, skills_tao_run_deft_aoi_skill, skills_tao_run_automl_deft_pipeline_skill [EXTRACTED 1.00]
- **TAO GPU Runtime Stack** — nvidia_driver_580, cuda_toolkit_13_0, nvidia_container_toolkit_1_19_0 [EXTRACTED 1.00]
- **Segmentation Models** — skills_tao_train_mask_auto_label_mal, skills_tao_train_mask_grounding_dino_mask_grounding_dino, skills_tao_train_mask2former_mask2former, skills_tao_train_nvpanoptix3d_nvpanoptix3d [EXTRACTED 1.00]
- **Self-Supervised Learning Models** — skills_tao_train_mask_auto_encoder_mae, skills_tao_train_nvdinov2_nvdinov2 [EXTRACTED 1.00]
- **TileGym Kernel Conversion Suite** — skills_tilegym_converting_cutile_to_julia_skill, skills_tilegym_converting_cutile_to_triton_skill [INFERRED 1.00]
- **Deep Agent Orchestration Pipeline** — skills_tilegym_cutile_python_orchestration_analyzer, skills_tilegym_cutile_python_orchestration_kernel, skills_tilegym_cutile_python_orchestration_composer [EXTRACTED 1.00]
- **VSS Deployment Ecosystem** — skills_vss_deploy_dense_captioning, skills_vss_deploy_detection_tracking_2d, skills_vss_deploy_detection_tracking_3d, skills_vss_deploy_video_embedding [EXTRACTED 1.00]
- **VSS Analytics Pipeline** — skills_vss_setup_behavior_analytics, skills_vss_setup_video_analytics_api, skills_vss_query_analytics [INFERRED 0.90]
- **VSS Video Reporting Flow** — skills_vss_generate_video_report, skills_vss_manage_video_io_storage, skills_vss_summarize_video [EXTRACTED 1.00]
- **Video Summarization Execution Flow** — skills_vss_summarize_video_skill, skills_vss_manage_video_io_storage_skill, skills_vss_summarize_video_lvs_service, skills_vss_summarize_video_vlm_endpoint [EXTRACTED 1.00]
- **Video Summarization Reference Material** — skills_vss_summarize_video_ref_api, skills_vss_summarize_video_ref_deployment, skills_vss_summarize_video_ref_debugging, skills_vss_summarize_video_ref_env [EXTRACTED 1.00]

## Communities (207 total, 155 thin omitted)

### Community 0 - "vss-deploy-profile"
Cohesion: 0.08
Nodes (38): Claude Code, Codex, LVS Summarization Microservice, NVIDIA AI Blueprint: Video Search and Summarization, RT-Embed Video Embedding, RT-VLM Dense Captioning, RTVI-CV 2D Detection/Tracking, RTVI-CV-3D (MV3DT) (+30 more)

### Community 1 - "Build BSP Source Skill"
Cohesion: 0.16
Nodes (20): Build BSP Source Skill, Customize Camera Skill, Customize Clocks Skill, Customize Fan Skill, Customize MGBE Skill, Customize nvpmodel Skill, Customize PCIe Skill, Customize Pinmux Skill (+12 more)

### Community 2 - "jetson-init-image"
Cohesion: 0.15
Nodes (17): jetson-customize-pinmux, generate_dtsi.py, modify_pinmux.py, jetson-customize-uphy, jetson-customize-usb, jetson-derive-carrier, jetson-download-bsp, jetson-flash-image (+9 more)

### Community 3 - "tao-run-automl"
Cohesion: 0.14
Nodes (17): Grounding DINO, Classification PyT, Mask2Former, MAE, MAL, Mask Grounding DINO, ML Recog, NVDINOv2 (+9 more)

### Community 4 - "Performance Tuning Guide"
Cohesion: 0.17
Nodes (14): Parallelisms Documentation, Performance Tuning Guide, nemo-mbridge-perf-expert-parallel-overlap, MoE Expert-Parallel Overlap Skill, nemo-mbridge-perf-hierarchical-context-parallel, nemo-mbridge-perf-megatron-fsdp, nemo-mbridge-perf-memory-tuning, nemo-mbridge-perf-moe-comm-overlap (+6 more)

### Community 5 - "Physical AI Infrastructure Setup And Resilient Scaling"
Cohesion: 0.13
Nodes (16): Azure AI Foundry Inference, Azure Cluster, MicroK8s Cluster, NIM Operator Inference, NVCF Inference, OSMO CLI, NVIDIA OSMO, Azure Access (+8 more)

### Community 6 - "tao-run-automl"
Cohesion: 0.18
Nodes (13): NVIDIA Container Toolkit 1.19.0, AutoML + DEFT Pipeline, tao-run-automl, DEFT Loop Reporter Agent, tao-run-deft-aoi, TAO Train Action Recognition, TAO Train BEVFusion, TAO Train CenterPose (+5 more)

### Community 7 - "sage-waggle skill"
Cohesion: 0.20
Nodes (9): Graphify Workflow, Profile Distribution Manifest, Foundry v2 Proposal, Sage-Waggle Skill Split Proposal, pywaggle SDK, Sage Camp Hermes Profile README, Graphify Skill, sage-waggle skill (+1 more)

### Community 8 - "TAO Run Platform"
Cohesion: 0.22
Nodes (9): TAO Generate Image Grounding, TAO Generate Referring Expressions, TAO Generate Video Reasoning Annotations, TAO Run Inference Service, TAO Run on Brev, TAO Run on Kubernetes, TAO Run on Local Docker, TAO Run on SLURM (+1 more)

### Community 9 - "NVIDIA RAG Blueprint"
Cohesion: 0.29
Nodes (8): NVIDIA RAG Blueprint, RAG Blueprint Skill, RAG Eval Skill, evaluate_rag.py, On-disk RAG evaluation, RAG Perf Skill, rag-perf CLI, RAG-Perf

### Community 10 - "Clinical ASR Eval"
Cohesion: 0.29
Nodes (8): Clinical ASR Build, Clinical ASR Eval, Clinical ASR Finetune, Clinical ASR Setup, Finetune ASR, Riva ASR, Riva ASR Custom, Riva NIM Setup

### Community 11 - "holoscan-setup"
Cohesion: 0.33
Nodes (7): holoscan-install-container, holoscan-install-debian, holoscan-install-source, holoscan-install-wheel, holoscan-setup, check_conda.sh, check_ngc_image.sh

### Community 12 - "jetson-diagnostic"
Cohesion: 0.29
Nodes (7): jetson-diagnostic, detect_jetson.sh, mem_summary.sh, snapshot.sh, jetson-headless-mode, apply.sh, plan.sh

### Community 13 - "TAO Inference Microservice"
Cohesion: 0.33
Nodes (7): TAO Inference Microservice, Brev Platform, Kubernetes Platform, Local Docker Platform, SLURM Platform, TAO Execution SDK, TAO Setup NVIDIA GPU Host

### Community 14 - "Deep Agent Orchestration Workflow"
Cohesion: 0.29
Nodes (7): cuTile to Triton Conversion Workflow, Analyzer Agent, Composer Agent, Kernel Agent, Deep Agent Orchestration Workflow, cuTile Python Programming Skill, PyTorch Implementation Tracing Workflow

### Community 16 - "Linear Programming"
Cohesion: 0.53
Nodes (6): Linear Programming, Mixed-Integer Linear Programming, Quadratic Programming, cuOpt Numerical Optimization API, Numerical Optimization Formulation, cuOpt Server Python API

### Community 17 - "SageMaker Deployment Planner Skill"
Cohesion: 0.53
Nodes (6): AWS Context Discovery Skill, Python Environment Setup for SageMaker Skill, SageMaker Deployment Planner Skill, SageMaker IAM Preflight Skill, SageMaker Production Defaults Skill, Serving Image Selection Skill

### Community 18 - "Holoscan Setup Skill"
Cohesion: 0.33
Nodes (6): Holoscan Conda Installation Skill, Holoscan Install Container Skill, Holoscan Install Debian Skill, Holoscan Install Source Skill, Holoscan Install Wheel Skill, Holoscan Setup Skill

### Community 19 - "nemo-automodel-model-onboarding Skill"
Cohesion: 0.47
Nodes (6): nemo-automodel-model-onboarding Benchmark, Model Capabilities and Precision, Dense LLM Implementation Patterns, nemo-automodel-model-onboarding Skill, nemo-automodel-model-onboarding Skill Card, VLM Implementation Patterns

### Community 20 - "nv-generate-mr-brain-finetune"
Cohesion: 0.33
Nodes (6): nv-generate-mr-brain, nv-generate-mr-brain-finetune, run_mr_brain_finetune.py, run_mr_brain.py, NV-Generate-VAE-Finetune, run_vae_finetune.py

### Community 21 - "TAO Train Single Step"
Cohesion: 0.47
Nodes (6): TAO Train SegFormer, TAO Train Single Step, TAO Train Sparse4D, TAO Train Visual ChangeNet, tao-launch-workflow, tao-run-automl

### Community 22 - "Calibrate Sample Dataset Skill"
Cohesion: 0.50
Nodes (5): scripts/run_sample_calibration.py, Calibrate Sample Dataset Skill, scripts/run_video_calibration.py, Calibrate from Video Files Skill, Launch AutoMagicCalib Release Containers Skill

### Community 23 - "TileGym cuTile Python Skill"
Cohesion: 0.40
Nodes (5): TileGym Converting cuTile to Julia Skill, TileGym Converting cuTile to Triton Skill, TileGym cuTile Python Skill, TileGym Improve cuTile Kernel Perf Skill, TileGym Monkey Patch Kernels to Transformers Skill

### Community 24 - "NVIDIA TAO Skill Bank"
Cohesion: 0.50
Nodes (4): NVIDIA TAO Skill Bank, TAO DAFT Dataset Converter, Cosmos-Embed Fine-tuning, Cosmos-RL (Cosmos3-Nano)

### Community 25 - "Clinical ASR Build Skill"
Cohesion: 0.50
Nodes (4): Clinical ASR Build Skill, Clinical ASR Eval Skill, Clinical ASR Finetune Skill, Clinical ASR Setup Skill

### Community 26 - "Dynamo Recipe Runner"
Cohesion: 0.83
Nodes (4): Dynamo Interconnect Check, Dynamo Recipe Runner, Dynamo Router Starter, Dynamo Troubleshoot

### Community 27 - "Gradio LoRA Space Builder"
Cohesion: 0.50
Nodes (4): Hugging Face Community Evals, Gradio UI Builder, Gradio LoRA Space Builder, Hugging Face Spaces

### Community 28 - "jetson-speculative-decoding"
Cohesion: 0.50
Nodes (4): jetson-inference-mem-tune, jetson-llm-benchmark, jetson-llm-serve, jetson-speculative-decoding

### Community 29 - "nemo-data-designer-plugin Skill"
Cohesion: 0.50
Nodes (4): nemo-data-designer-plugin Benchmark, nemo-data-designer-plugin Skill, Autopilot Workflow, Interactive Workflow

### Community 30 - "Activation Recompute Skill"
Cohesion: 0.50
Nodes (4): Activation Recompute Skill, CUDA Graphs Skill, Megatron FSDP Skill, Memory Tuning Skill

### Community 31 - "Physical AI Video Data Augmentation Workflow Orchestrator"
Cohesion: 0.50
Nodes (4): pre_submit_guard.py, preflight_credentials.sh, prepare_demo_assets.sh, Physical AI Video Data Augmentation Workflow Orchestrator

### Community 32 - "Skill Card Generator"
Cohesion: 0.50
Nodes (4): Skill Card Generator, discover_assets.py, render_card.py, validate_submission.py

### Community 33 - "AIQ Research Skill"
Cohesion: 0.67
Nodes (3): aiq-deploy Skill, scripts/aiq.py, AIQ Research Skill

### Community 34 - "Data Designer Skill"
Cohesion: 0.67
Nodes (3): Data Designer Skill, Autopilot Workflow, Interactive Workflow

### Community 35 - "DeepStream Profiling Skill"
Cohesion: 0.67
Nodes (3): DeepStream Pipeline Builder, DeepStream Import Vision Model, DeepStream Profiling Skill

### Community 36 - "Dynamo Troubleshoot Skill"
Cohesion: 0.67
Nodes (3): Dynamo Recipe Runner Skill, Dynamo Router Starter Skill, Dynamo Troubleshoot Skill

### Community 37 - "Earth2Studio Create Prognostic Skill"
Cohesion: 0.67
Nodes (3): Earth2Studio Create Diagnostic Skill, Earth2Studio Create Prognostic Skill, Earth2Studio Deterministic Forecast Skill

### Community 38 - "Earth2Studio Deterministic Forecast Skill"
Cohesion: 0.67
Nodes (3): Earth2Studio Deterministic Forecast Skill, Earth2Studio Discoverability Skill, Earth2Studio Installation Skill

### Community 39 - "hsb-setup"
Cohesion: 0.67
Nodes (3): hsb-app, hsb-setup, hsb-test

### Community 40 - "Trackio Experiment Tracking"
Cohesion: 0.67
Nodes (3): Hugging Face LLM Trainer, Trackio Experiment Tracking, Hugging Face Vision Trainer

### Community 41 - "jetson-llm-benchmark"
Cohesion: 1.00
Nodes (3): jetson-llm-benchmark, jetson-llm-serve, jetson-package

### Community 42 - "nemo-automodel-launcher-config Skill"
Cohesion: 0.67
Nodes (3): nemo-automodel-launcher-config Benchmark, nemo-automodel-launcher-config Skill, nemo-automodel-launcher-config Skill Card

### Community 43 - "nemo-automodel-recipe-development Skill"
Cohesion: 0.67
Nodes (3): nemo-automodel-recipe-development Benchmark, nemo-automodel-recipe-development Skill, nemo-automodel-recipe-development Skill Card

### Community 44 - "nemo-evaluator-plugin Skill"
Cohesion: 0.67
Nodes (3): nemo-evaluator-plugin Benchmark, nemo-evaluator-plugin Skill, nemo-evaluator-plugin Skill Card

### Community 45 - "nemo-mbridge-mlm-bridge-training Skill"
Cohesion: 0.67
Nodes (3): nemo-mbridge-mlm-bridge-training Benchmark, nemo-mbridge-mlm-bridge-training Skill, nemo-mbridge-mlm-bridge-training Skill Card

### Community 46 - "Auto Research"
Cohesion: 0.67
Nodes (3): Auto Research, Brev Etiquette, Session Memory

### Community 47 - "NV-Reason-CXR"
Cohesion: 0.67
Nodes (3): NV-Reason-CXR, run_nv_reason_cxr.py, NVIDIA Skill Finder

### Community 48 - "TAO Run AutoML"
Cohesion: 0.67
Nodes (3): TAO Launch Workflow, TAO Run AutoML, TAO Run AutoML DEFT Pipeline

### Community 49 - "TAO Route Visual ChangeNet Samples"
Cohesion: 0.67
Nodes (3): TAO Mine AOI Images, TAO Route Visual ChangeNet Samples, TAO Run DEFT AOI

## Knowledge Gaps
- **348 isolated node(s):** `accelerated-computing-cudf skill`, `aiq-deploy skill`, `Graphify Workflow`, `pywaggle2 Acquisition Ladder`, `Two-Layer Cache Eviction` (+343 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **155 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What connects `accelerated-computing-cudf skill`, `aiq-deploy skill`, `Graphify Workflow` to the rest of the system?**
  _348 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `vss-deploy-profile` be split into smaller, more focused modules?**
  _Cohesion score 0.07681365576102418 - nodes in this community are weakly interconnected._
- **Should `tao-run-automl` be split into smaller, more focused modules?**
  _Cohesion score 0.13970588235294118 - nodes in this community are weakly interconnected._
- **Should `Physical AI Infrastructure Setup And Resilient Scaling` be split into smaller, more focused modules?**
  _Cohesion score 0.13333333333333333 - nodes in this community are weakly interconnected._