#!/root/.hermes/profiles/sage/.venv-graphify/bin/python
"""Incremental graphify --update runner for mlevij_node-H02E."""
import json, sys
from pathlib import Path

PROFILE = Path("/root/2026-summer-camp-sage-agent-logs/hermes/public/archives/mlevij_node-H02E/sage")
PYTHON = Path("/root/.hermes/profiles/sage/.venv-graphify/bin/python")
OUT = PROFILE / "graphify-out"

# Write .graphify_python marker
(OUT / ".graphify_python").write_text(str(PYTHON), encoding="utf-8")
print(f"Python: {PYTHON}")

# Step 1: detect
from graphify.detect import detect
r = detect(PROFILE)
(OUT / ".graphify_detect.json").write_text(json.dumps(r, ensure_ascii=False), encoding="utf-8")
print(f"Detected: {r.get('total_files', 0)} files")

# Step 2: check cache
from graphify.cache import check_semantic_cache
all_files = [f for cat in ('document', 'paper', 'image') for f in r.get('files', {}).get(cat, [])]
cn, ce, ch, un = check_semantic_cache(all_files, root=str(PROFILE))
print(f"Cache: {len(all_files)-len(un)} hit, {len(un)} uncached")
if cn or ce or ch:
    (OUT / ".graphify_cached.json").write_text(json.dumps({'nodes':cn,'edges':ce,'hyperedges':ch}), encoding="utf-8")
else:
    (OUT / ".graphify_cached.json").unlink(missing_ok=True)

# Step 3: AST extract
from graphify.extract import collect_files, extract
cf = []
for f in r.get('files', {}).get('code', []):
    p = Path(f)
    if p.is_file():
        cf.append(p)
    elif p.is_dir():
        cf.extend(p.iterdir())
if cf:
    ast = extract(cf, cache_root=PROFILE)
    (OUT / ".graphify_ast.json").write_text(json.dumps(ast), encoding="utf-8")
    print(f"AST: {len(ast['nodes'])} nodes")
else:
    (OUT / ".graphify_ast.json").write_text(json.dumps({'nodes':[],'edges':[],'input_tokens':0,'output_tokens':0}), encoding="utf-8")
    print("No code files - skipping AST")

# Step 3b: empty semantic (no LLM)
(OUT / ".graphify_semantic.json").write_text(json.dumps({'nodes':[],'edges':[],'hyperedges':[],'input_tokens':0,'output_tokens':0}), encoding="utf-8")

# Step 4: merge
ast = json.loads((OUT / ".graphify_ast.json").read_text(encoding="utf-8"))
sem = json.loads((OUT / ".graphify_semantic.json").read_text(encoding="utf-8"))
seen = {n['id'] for n in ast['nodes']}
mn = list(ast['nodes'])
for n in sem['nodes']:
    if n['id'] not in seen:
        mn.append(n)
        seen.add(n['id'])
merged = {
    'nodes': mn,
    'edges': ast['edges'] + sem['edges'],
    'hyperedges': sem.get('hyperedges', []),
}
(OUT / ".graphify_extract.json").write_text(json.dumps(merged, ensure_ascii=False), encoding="utf-8")
print(f"Merged: {len(mn)} nodes")

# Step 5: build, cluster, analyze, report
from graphify.build import build_from_json
from graphify.cluster import cluster, score_all
from graphify.analyze import god_nodes, surprising_connections, suggest_questions
from graphify.report import generate
from graphify.export import to_json

G = build_from_json(merged, root=str(PROFILE))
if G.number_of_nodes() == 0:
    print("ERROR: Graph is empty.")
    sys.exit(1)

c = cluster(G)
coh = score_all(G, c)
lbl = {cid: f'Community {cid}' for cid in c}
q = suggest_questions(G, c, lbl)

wrote = to_json(G, c, str(OUT / "graph.json"), force=True)
print(f"Graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges, {len(c)} communities")

report = generate(G, c, coh, lbl, god_nodes(G), surprising_connections(G, c), r, {'input':0,'output':0}, str(PROFILE), suggested_questions=q)
(OUT / "GRAPH_REPORT.md").write_text(report, encoding="utf-8")

# Step 6: save manifest
from graphify.detect import save_manifest
save_manifest(r.get('all_files') or r['files'], root=str(PROFILE))
print("Manifest saved")

# Cleanup temp files
for f in [".graphify_detect.json", ".graphify_extract.json", ".graphify_ast.json",
          ".graphify_semantic.json", ".graphify_cached.json"]:
    (OUT / f).unlink(missing_ok=True)

print("DONE: mlevij_node-H02E")
